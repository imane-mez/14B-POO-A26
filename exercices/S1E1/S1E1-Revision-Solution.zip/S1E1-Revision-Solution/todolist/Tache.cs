﻿using System;
using System.Collections.Generic;
using System.Text;

namespace todolist
{
    struct Tache
    {
        //Titre de la tâche.
        public string Titre;

        //Description de la tâche.
        public string Description;

        //Indique si la tâche est réalisée ou non.
        public Boolean Completee;


    }

}
