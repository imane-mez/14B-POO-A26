﻿using todolist;


internal class Program
{
    //Constantes
    private const string CHEMIN_FICHIER = @"C:\data-420-14B-FX\taches.csv";

    private static void Main(string[] args)
    {
        //Création du vecteur contenant les tâches.
        Tache[] vectTaches = ObtenirTaches(CHEMIN_FICHIER);

        char choixMenu;

        do
        {
            //Demande le choix à  l'utlisateur à parti du menu.
            choixMenu = DemanderChoixMenu();

            switch (choixMenu)
            {
                case '1':
                    //Affichage de la liste des tâches
                    AfficherTaches(vectTaches);

                    break;
                case '2':

                    //Saisie du titre de la nouvelle tâche
                    Console.Write("Veuillez saisir le tire de la tâche : ");
                    string titre = Console.ReadLine();

                    //Saisie de la description de la tâche
                    Console.Write("Veuillez saisir la description de la tâche : ");
                    string description = Console.ReadLine();

                    //Ajout de la nouvelle tâche et remplacement du vecteur de tâche
                    //par  le nouveau vecteur reçu de la fonction.
                    vectTaches = AjouterTache(titre, description, vectTaches);

                    //Affichage de la liste des tâches
                    AfficherTaches(vectTaches);

                    break;

                case '3':


                    //Vérification s'il existe des tâches dans le vecteur.
                    if (vectTaches.Length == 0)
                    {
                        Console.WriteLine("Il n'y a aucune tâche non complétée.");
                    }
                    else
                    {
                        //Saisi du numéro de la tâche complée
                        Console.Write("Veuillez saisire le numéro de la tâche complétée: ");
                        int index = int.Parse(Console.ReadLine());

                        //Vérification si l'index spécifié existe dans le vecteur.
                        if (index < 1 || index > vectTaches.Length)
                        {
                            Console.WriteLine("Le numéro de la tâche inscrit n'existe pas!");
                        }
                        else
                        {
                            //Modification de l'indicateur complété de la tâche
                            vectTaches[index - 1].Completee = true;


                        }
                    }


                    break;
                case '4':
                    //Enregistrement des tâches
                    EnregistrerTaches(vectTaches, CHEMIN_FICHIER);

                    Console.WriteLine("Les tâches ont été enregistrées avec succès!");
                    break;
                case '5':
                    Console.WriteLine("Fin du programme.");
                    break;
                default:
                    Console.WriteLine("Erreur : Choix invalide");
                    break;
            }

            if (choixMenu != '5')
            {
                // Pause : Permet à utilisateur de voir le résultat de l'opération.
                Console.WriteLine("\nAppuyez sur une touche pour retourner au menu principal.");
                Console.ReadKey();
            }

        } while (choixMenu != '5');


    }


    /// <summary>
    /// Permet à l'utilisateur de faire un choix dans le menu
    /// </summary>
    /// <returns>Le choix de l'utilisateur dans le menu.</returns>
    static char DemanderChoixMenu()
    {
        // Affichage du menu principal.
        Console.Clear();
        Console.WriteLine("======================================================");
        Console.WriteLine("MENU PRINCIPAL");
        Console.WriteLine("======================================================");
        Console.WriteLine("1) Afficher la liste des tâches.");
        Console.WriteLine("2) Ajouter une tâche.");
        Console.WriteLine("3) Indique une tâche comme étant complétée");
        Console.WriteLine("4) Enregistrer la liste des tâches.");
        Console.WriteLine("5) Fin du programme.");
        Console.WriteLine("======================================================");

        Console.Write("\nSaisir votre choix ? ");
        char choixMenu = Console.ReadKey().KeyChar;
        Console.WriteLine("\n");

        return choixMenu;
    }

    /// <summary>
    /// Permet l'affichage de la liste des tâches complétées.
    /// </summary>
    /// <param name="vectTaches">Vecteurs contenant les tâches.</param>
    static void AfficherTaches(Tache[] vectTaches)
    {
        Console.WriteLine();
        Console.WriteLine("-----------------------------------------------");
        Console.WriteLine("{0,-4}|{1,-25}|{2}", "No.", "Titre", "Description");
        Console.WriteLine("-----------------------------------------------");


        for (int i = 0; i < vectTaches.Length; i++)
        {
            if (!vectTaches[i].Completee)
                Console.WriteLine($"{i + 1 + ")",-4} {vectTaches[i].Titre,-25} {vectTaches[i].Description}");
        }
    }

    /// <summary>
    /// Permet d'obtenir un vecteur de tâche. Utilise la fonction LireFichier
    /// pour obtenir la liste des tâches contenu dans le fichier et créer un vecteur de tâches.
    /// </summary>
    /// <param name="cheminFichier">Chemin d'accès au fichier contenant les tâches</param>
    /// <returns>Vecteur contant les tâches</returns>
    public static Tache[] ObtenirTaches(string cheminFichier)
    {
        //Appel de la fonction qui retourne les lignes contenues dans le fichier
        string[] vectLignes = FonctionsUtiles.LireFichier(cheminFichier);


        //Création d'un vecteur de tâches
        Tache[] vectTaches;

        //Vérification si la dernière ligne est vide et création du vecteur de tâches
        if (vectLignes[vectLignes.Length - 1] == "")
            vectTaches = new Tache[vectLignes.Length - 1];
        else
            vectTaches = new Tache[vectLignes.Length];



        //Parcours des lignes pour créer les tâches dans le vecteur
        for (int i = 0; i < vectTaches.Length; i++)
        {
            string[] vectChamps = vectLignes[i].Split(';');

            vectTaches[i].Titre = vectChamps[0];
            vectTaches[i].Description = vectChamps[1];
            vectTaches[i].Completee = Convert.ToBoolean(vectChamps[2]);

        }

        return vectTaches;
    }


    /// <summary>
    /// Permet l'ajout d'une tâche à un nouveau vecteur de tâche. Copie les tâches contenues
    /// dans le vecteur reçu en paramètre dans un nouveau vecteur et ajoutre la nouvelle tâche 
    /// au nouveau vecteur. 
    /// </summary>
    /// <param name="titre">Titre de la tâche</param>
    /// <param name="description">Description de la tâche</param>
    /// <param name="vectTaches">Vecteur contenant les tâches</param>
    /// <returns>Un nouveau vecteur contenant les tâche de vecTaches en plus de la nouvelle tâche créée</returns>
    public static Tache[] AjouterTache(string titre, string description, Tache[] vectTaches)
    {
        //Création d'une nouvelle tâche
        Tache nouvelleTache = new Tache();
        nouvelleTache.Titre = titre;
        nouvelleTache.Description = description;
        nouvelleTache.Completee = false;

        //Création d'un nouveau vecteur de la taille du vecteur de tâches + 1
        Tache[] vectNouveauTaches = new Tache[vectTaches.Length + 1];

        //Copie des taches existantes dans le nouveau vecteur
        for (int i = 0; i < vectTaches.Length; i++)
        {
            vectNouveauTaches[i] = vectTaches[i];
        }

        //Ajoute de la nouvelle tâche à la fin du vecteur
        vectNouveauTaches[vectNouveauTaches.Length - 1] = nouvelleTache;

        return vectNouveauTaches;

    }
    /// <summary>
    /// Permet l'enregistrement des tâches. Converti les tâches reçues en paramètre en une chaîne de caractère,
    /// les transfers dans un vecteur de chaînes de caractère et utiliser la fonction EcrireFichier
    /// pour écrire la liste des tâches dans un fichier.
    /// </summary>
    /// <param name="vectTaches">Vecteur contenant les tâches à enregistrer</param>
    /// <param name="cheminFichier">Chemin d'accès au fichier</param>
    public static void EnregistrerTaches(Tache[] vectTaches, string cheminFichier)
    {
        //Créatio d'un vecteur de ligne selon la taille du vecteur de tâches
        string[] vectLignes = new string[vectTaches.Length];

        //Pacours du vecteur de tâche pour créer les lignes à ajouter au fichier.
        for (int i = 0; i < vectTaches.Length; i++)
        {
            vectLignes[i] = vectTaches[i].Titre + ";" + vectTaches[i].Description + ";" + vectTaches[i].Completee;

        }

        //Appel de la fonction qui écrit les lignes dans le fichier
        FonctionsUtiles.EcrireFichier(vectLignes, cheminFichier);

    }
}