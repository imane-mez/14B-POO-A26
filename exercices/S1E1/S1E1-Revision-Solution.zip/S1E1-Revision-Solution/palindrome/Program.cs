﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.Write("Entrez une phrase : ");

        string chaine = Console.ReadLine();


        // Nombre de comparaisons à effectuer dans le pire des cas.
        int nbComp = chaine.Length / 2;

        bool estPalindrome = true;
        int indice = 0;

        do
        {
            if (chaine[indice] != chaine[chaine.Length - indice - 1])
                estPalindrome = false;

            indice++;
        } while (estPalindrome && indice < nbComp);


        if (estPalindrome)
            Console.WriteLine("C'est un palindrome");
        else
            Console.WriteLine("Ce n'est pas un palindrome");

        Console.ReadKey();

    }


    static string FormaterChaine(string chaine)
    {
        //Retrait des espaces
        chaine = chaine.Replace(" ", "");



        //Conversion en minuscule tous les caractèrs
        chaine = chaine.ToLower();

        //Remplacement des ponctuations
        chaine = chaine.Replace(".", "").Replace(",", "").Replace(";", "").Replace("?", "").Replace("!", "").Replace("'", "").Replace("-", "");

        //Remplacement des accents
        chaine = chaine.Replace("à", "a").Replace("â", "a");
        chaine = chaine.Replace("é", "e").Replace("è", "e").Replace("ê", "e").Replace("ë", "e");
        chaine = chaine.Replace("ï", "i").Replace("î", "i");
        chaine = chaine.Replace("ö", "o").Replace("ô", "o");
        chaine = chaine.Replace("ù", "u").Replace("ü", "u").Replace("û", "u");
        chaine = chaine.Replace("ç", "c");



        return chaine;
    }
}