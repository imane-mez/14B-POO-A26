﻿using todolist;


internal class Program
{
    //Constantes
    private const string CHEMIN_FICHIER = @"C:\data-420-14B-FX\taches.csv";

    private static void Main(string[] args)
    {
 
        //TODO : Création du vecteur contenant les tâches à partir des tâche contenu dans le fichier.

        char choixMenu = '0';

        do
        {
            
            //TODO: Demande le choix à  l'utlisateur à parti du menu.

            switch (choixMenu)
            {
                case '1':
                    //TODO: Affichage de la liste des tâches à partir de la fonction

                    break;
                case '2':

                    //TODO : Ajout d'une nouvelle tâche.

                    //Saisie du titre de la nouvelle tâche


                    //Saisie de la description de la tâche


                    //Ajout de la nouvelle tâche et remplacement du vecteur de tâche
                    //par le nouveau vecteur reçu de la fonction.


                    //Affichage de la liste des tâches

                    break;

                case '3': //OPTIONNEL!


                    //TODO : Modification d'une tâche.

                    //Vérification s'il existe des tâches dans le vecteur. Sinon affichage d'un message
                    //à l'utilisateur.

                    //Saisi du numéro de la tâche complétée

                    //Vérification si l'index spécifié existe dans le vecteur.

                    //Modification de l'indicateur complété de la tâche


                    break;
                case '4':
                    //TODO : Enregistrement des tâches

                    //Rétroaction à l'utlisateur pour indiquer que cela a fonctionné
                    break;
                case '5':
                    Console.WriteLine("Fin du programme.");
                    break;
                default:
                    Console.WriteLine("Erreur : Choix invalide");
                    break;
            }

            if (choixMenu != '5')
            {
                // Pause : Permet à utilisateur de voir le résultat de l'opération.
                Console.WriteLine("\nAppuyez sur une touche pour retourner au menu principal.");
                Console.ReadKey();
            }

        } while (choixMenu != '5');


    }


    /// <summary>
    /// Permet à l'utilisateur de faire un choix dans le menu
    /// </summary>
    /// <returns>Le choix de l'utilisateur dans le menu.</returns>
    static char DemanderChoixMenu()
    {
        // Affichage du menu principal.
        Console.Clear();
        Console.WriteLine("======================================================");
        Console.WriteLine("MENU PRINCIPAL");
        Console.WriteLine("======================================================");
        Console.WriteLine("1) Afficher la liste des tâches.");
        Console.WriteLine("2) Ajouter une tâche.");
        Console.WriteLine("3) Indique une tâche comme étant complétée");
        Console.WriteLine("4) Enregistrer la liste des tâches.");
        Console.WriteLine("5) Fin du programme.");
        Console.WriteLine("======================================================");

        Console.Write("\nSaisir votre choix ? ");
        char choixMenu = Console.ReadKey().KeyChar;
        Console.WriteLine("\n");

        return choixMenu;
    }

    /// <summary>
    /// Permet l'affichage de la liste des tâches complétées.
    /// </summary>
    /// <param name="vectTaches">Vecteurs contenant les tâches.</param>
    static void AfficherTaches(Tache[] vectTaches)
    {
        Console.WriteLine();
        Console.WriteLine("-----------------------------------------------");
        Console.WriteLine("{0,-4}|{1,-25}|{2}", "No.", "Titre", "Description");
        Console.WriteLine("-----------------------------------------------");


        for (int i = 0; i < vectTaches.Length; i++)
        {
            if (!vectTaches[i].Completee)
                Console.WriteLine($"{i + 1 + ")",-4} {vectTaches[i].Titre,-25} {vectTaches[i].Description}");
        }
    }

    /// <summary>
    /// Permet d'obtenir un vecteur de tâche. Utilise la fonction LireFichier
    /// pour obtenir la liste des tâches contenu dans le fichier et créer un vecteur de tâches.
    /// </summary>
    /// <param name="cheminFichier">Chemin d'accès au fichier contenant les tâches</param>
    /// <returns>Vecteur contant les tâches</returns>
    public static Tache[] ObtenirTaches(string cheminFichier)
    {
        //TODO: Compléter le code la fonction ObtenirTaches.

        return null; //À remplacer
    }


    /// <summary>
    /// Permet l'ajout d'une tâche à un nouveau vecteur de tâche. Copie les tâches contenues
    /// dans le vecteur reçu en paramètre dans un nouveau vecteur et ajoutre la nouvelle tâche 
    /// au nouveau vecteur. 
    /// </summary>
    /// <param name="titre">Titre de la tâche</param>
    /// <param name="description">Description de la tâche</param>
    /// <param name="vectTaches">Vecteur contenant les tâches</param>
    /// <returns>Un nouveau vecteur contenant les tâche de vecTaches en plus de la nouvelle tâche créée</returns>
    public static Tache[] AjouterTache(string titre, string description, Tache[] vectTaches)
    {
        //TODO: Compléter le code la fonction AjouterTache.

        return null; //À remplacer

    }


    /// <summary>
    /// Permet l'enregistrement des tâches. 
    /// Copie les tâches reçu en paramètre dans un vecteur de chaînes de caractère et utiliser la fonction EcrireFichier
    /// pour écrire la liste des tâches dans un fichier.Chaque tâche est une chaîne de caractère dont les valeurs sont 
    /// séparées par un point-virgule.
    /// </summary>
    /// <param name="vectTaches">Vecteur contenant les tâches à enregistrer</param>
    /// <param name="cheminFichier">Chemin d'accès au fichier</param>
    public static void EnregistrerTaches(Tache[] vectTaches, string cheminFichier)
    {
        //Créatio d'un vecteur de ligne selon la taille du vecteur de tâches
        string[] vectLignes = new string[vectTaches.Length];

        //Pacours du vecteur de tâche pour créer les lignes à ajouter au fichier.
        for (int i = 0; i < vectTaches.Length; i++)
        {
            vectLignes[i] = vectTaches[i].Titre + ";" + vectTaches[i].Description + ";" + vectTaches[i].Completee;

        }

        //Appel de la fonction qui écrit les lignes dans le fichier
        FonctionsUtiles.EcrireFichier(vectLignes, cheminFichier);

    }
}