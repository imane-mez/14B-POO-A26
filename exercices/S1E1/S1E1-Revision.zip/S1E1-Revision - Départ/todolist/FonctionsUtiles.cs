﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace todolist
{
    static class FonctionsUtiles
    {
        /// <summary>
        /// Permet de lire un fichier et de retourner chaque lignes
        /// contenu dans le fichier dans un vecteur de chaînes de caractères
        /// </summary>
        /// <param name="cheminFichier">Chemin d'accès au fichier</param>
        /// <returns>Vecteur de chaînes de caractères représentant les lignes du fichier</returns>
        public static string[] LireFichier(string cheminFichier)
        {
            //Ouverture du fichier
            StreamReader fichierLecture = new StreamReader(cheminFichier);

            // Lecture de l'ensemble du fichier en une seule instruction.
            string contenuFichier = fichierLecture.ReadToEnd();

            // Fermeture du fichier en entrée.
            fichierLecture.Close();

            // Retrait des "carriage return" ('\r'), s'il y en a.
            contenuFichier = contenuFichier.Replace("\r", "");

            // Création d'un vecteur de chaînes de caractères contenant chaque ligne individuellement.
            String[] vectLignes = contenuFichier.Split('\n');


            return vectLignes;


        }
        /// <summary>
        /// Permet d'écrire le contenu du vecteur de chaîne de caractères dans un fichier.
        /// chaque élément du vecteur représente une ligne dans le fichier.
        /// </summary>
        /// <param name="vectLignes">Vecteur contenant les chaînes de caractères à écrire dans le fichier</param>
        /// <param name="cheminFichier">Chemin d'accès au fichier pour l'écriture</param>
        public static void EcrireFichier(string[] vectLignes, string cheminFichier)
        {
            //Ouverture du fichier
            StreamWriter fichierEcriture = new StreamWriter(cheminFichier);

            //Écriture de chaque ligne du vecteur dans le fichier
            for (int i = 0; i < vectLignes.Length; i++)
            {
                fichierEcriture.WriteLine(vectLignes[i]);

            }

            //Fermeture du fichier
            fichierEcriture.Close();


        }




    }
}
